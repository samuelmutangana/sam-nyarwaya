
  # Recipe Discovery App

  This is a code bundle for Recipe Discovery App. The original project is available at https://www.figma.com/design/nqGgyVS5wD6op5zjoWlt1r/Recipe-Discovery-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  