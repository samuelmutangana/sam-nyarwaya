import { useState } from 'react';
import { X, Download, Upload as UploadIcon, Plus, Trash2, Star, Eye, EyeOff } from 'lucide-react';
import { PortfolioItem, SiteSettings, Skill, Testimonial, AboutMe, ContactMessage, AnalyticsData } from '../types';
import { AdminProjects } from './admin/AdminProjects';
import { AdminSettings } from './admin/AdminSettings';
import { AdminSkills } from './admin/AdminSkills';
import { AdminTestimonials } from './admin/AdminTestimonials';
import { AdminAbout } from './admin/AdminAbout';
import { AdminMessages } from './admin/AdminMessages';
import { AdminStatistics } from './admin/AdminStatistics';
import { AdminTabs } from './admin/AdminTabs';
import { AdminLogin } from './admin/AdminLogin';

interface EnhancedAdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
  // Projects
  portfolioItems: PortfolioItem[];
  onAddItem: (item: Omit<PortfolioItem, 'id'>) => void;
  onDeleteItem: (id: string) => void;
  // Settings
  settings: SiteSettings;
  onUpdateSettings: (settings: SiteSettings) => void;
  // Skills
  skills: Skill[];
  onAddSkill: (skill: Omit<Skill, 'id'>) => void;
  onDeleteSkill: (id: string) => void;
  // Testimonials
  testimonials: Testimonial[];
  onAddTestimonial: (testimonial: Omit<Testimonial, 'id'>) => void;
  onDeleteTestimonial: (id: string) => void;
  // About
  about: AboutMe;
  onUpdateAbout: (about: AboutMe) => void;
  // Messages
  messages: ContactMessage[];
  onDeleteMessage: (id: string) => void;
  onMarkMessageRead: (id: string) => void;
  // Analytics
  analytics: AnalyticsData;
}

export function EnhancedAdminPanel(props: EnhancedAdminPanelProps) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [activeTab, setActiveTab] = useState<'projects' | 'settings' | 'skills' | 'testimonials' | 'about' | 'messages' | 'export' | 'statistics'>('statistics');

  const handleLogin = (password: string) => {
    if (password === props.settings.adminPassword) {
      setIsAuthenticated(true);
    } else {
      alert('Incorrect password');
      return false;
    }
    return true;
  };

  const handleClose = () => {
    setIsAuthenticated(false);
    props.onClose();
  };

  const handleExport = () => {
    const data = {
      portfolioItems: props.portfolioItems,
      skills: props.skills,
      testimonials: props.testimonials,
      about: props.about,
      settings: props.settings,
      messages: props.messages,
    };
    
    const dataStr = JSON.stringify(data, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `portfolio-backup-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = JSON.parse(event.target?.result as string);
        
        if (data.portfolioItems) {
          data.portfolioItems.forEach((item: any) => {
            if (!props.portfolioItems.find(p => p.id === item.id)) {
              props.onAddItem(item);
            }
          });
        }
        
        if (data.skills) {
          data.skills.forEach((skill: any) => {
            if (!props.skills.find(s => s.id === skill.id)) {
              props.onAddSkill(skill);
            }
          });
        }
        
        if (data.testimonials) {
          data.testimonials.forEach((testimonial: any) => {
            if (!props.testimonials.find(t => t.id === testimonial.id)) {
              props.onAddTestimonial(testimonial);
            }
          });
        }
        
        if (data.about) {
          props.onUpdateAbout(data.about);
        }
        
        alert('Data imported successfully!');
      } catch (error) {
        alert('Error importing data. Please check the file format.');
      }
    };
    reader.readAsText(file);
  };

  if (!props.isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto">
      <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-3xl shadow-[0_0_60px_rgba(16,185,129,0.4)] max-w-7xl w-full max-h-[95vh] overflow-hidden flex flex-col border border-emerald-500/30 my-4">
        {!isAuthenticated ? (
          <AdminLogin onLogin={handleLogin} onClose={handleClose} />
        ) : (
          <>
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-emerald-500/30 bg-gradient-to-r from-emerald-600 to-teal-600 shadow-[0_4px_20px_rgba(0,0,0,0.3)]">
              <h2 className="text-2xl text-white">Admin Dashboard</h2>
              <button 
                onClick={handleClose}
                className="text-white hover:bg-white/20 p-2 rounded-xl transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Tabs */}
            <AdminTabs activeTab={activeTab} onTabChange={setActiveTab} messageCount={props.messages.filter(m => m.status === 'new').length} />

            <div className="flex-1 overflow-y-auto p-6">
              {activeTab === 'projects' && (
                <AdminProjects
                  items={props.portfolioItems}
                  onAdd={props.onAddItem}
                  onDelete={props.onDeleteItem}
                />
              )}

              {activeTab === 'settings' && (
                <AdminSettings
                  settings={props.settings}
                  onUpdate={props.onUpdateSettings}
                />
              )}

              {activeTab === 'skills' && (
                <AdminSkills
                  skills={props.skills}
                  onAdd={props.onAddSkill}
                  onDelete={props.onDeleteSkill}
                />
              )}

              {activeTab === 'testimonials' && (
                <AdminTestimonials
                  testimonials={props.testimonials}
                  onAdd={props.onAddTestimonial}
                  onDelete={props.onDeleteTestimonial}
                />
              )}

              {activeTab === 'about' && (
                <AdminAbout
                  about={props.about}
                  onUpdate={props.onUpdateAbout}
                />
              )}

              {activeTab === 'messages' && (
                <AdminMessages
                  messages={props.messages}
                  onDelete={props.onDeleteMessage}
                  onMarkRead={props.onMarkMessageRead}
                />
              )}

              {activeTab === 'export' && (
                <div className="max-w-2xl mx-auto space-y-6">
                  <div className="bg-gradient-to-br from-gray-700/50 to-gray-800/50 rounded-2xl p-8 border border-emerald-500/20">
                    <h3 className="text-2xl text-emerald-400 mb-4">Export Data</h3>
                    <p className="text-gray-300 mb-6">Download all your portfolio data as a backup</p>
                    <button
                      onClick={handleExport}
                      className="flex items-center gap-2 bg-gradient-to-r from-emerald-500 to-teal-600 text-white px-6 py-3 rounded-xl hover:shadow-[0_0_30px_rgba(16,185,129,0.5)] transition-all"
                    >
                      <Download className="w-5 h-5" />
                      Export All Data
                    </button>
                  </div>

                  <div className="bg-gradient-to-br from-gray-700/50 to-gray-800/50 rounded-2xl p-8 border border-emerald-500/20">
                    <h3 className="text-2xl text-emerald-400 mb-4">Import Data</h3>
                    <p className="text-gray-300 mb-6">Restore your portfolio data from a backup file</p>
                    <input
                      type="file"
                      accept=".json"
                      onChange={handleImport}
                      className="hidden"
                      id="importFile"
                    />
                    <label
                      htmlFor="importFile"
                      className="inline-flex items-center gap-2 bg-gradient-to-r from-emerald-500 to-teal-600 text-white px-6 py-3 rounded-xl hover:shadow-[0_0_30px_rgba(16,185,129,0.5)] transition-all cursor-pointer"
                    >
                      <UploadIcon className="w-5 h-5" />
                      Import Data
                    </label>
                  </div>
                </div>
              )}

              {activeTab === 'statistics' && (
                <AdminStatistics
                  analytics={props.analytics}
                />
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}