import { Mail, Phone, MapPin, Instagram, Youtube, Linkedin } from 'lucide-react';
import { SiteSettings } from '../types';

interface FooterProps {
  settings: SiteSettings;
}

export function Footer({ settings }: FooterProps) {
  return (
    <footer className="bg-black border-t border-emerald-500/20 py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl mb-4 bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">
              Sam Nyarwaya
            </h3>
            <p className="text-gray-400">
              Professional Video Editor - Camera work, video editing, and graphic design services to bring your creative vision to life.
            </p>
          </div>

          <div>
            <h4 className="mb-4 text-emerald-400">Contact Info</h4>
            <div className="space-y-3 text-gray-400">
              <div className="flex items-center gap-3">
                <div className="bg-gradient-to-br from-emerald-500/20 to-teal-500/20 p-2 rounded-lg border border-emerald-500/30">
                  <Mail className="w-4 h-4 text-emerald-400" />
                </div>
                <a href={`mailto:${settings.email}`} className="hover:text-emerald-400 transition-colors">
                  {settings.email}
                </a>
              </div>
              <div className="flex items-center gap-3">
                <div className="bg-gradient-to-br from-emerald-500/20 to-teal-500/20 p-2 rounded-lg border border-emerald-500/30">
                  <Phone className="w-4 h-4 text-emerald-400" />
                </div>
                <a href={`tel:${settings.phone}`} className="hover:text-emerald-400 transition-colors">
                  {settings.phone}
                </a>
              </div>
              <div className="flex items-center gap-3">
                <div className="bg-gradient-to-br from-emerald-500/20 to-teal-500/20 p-2 rounded-lg border border-emerald-500/30">
                  <MapPin className="w-4 h-4 text-emerald-400" />
                </div>
                <span>{settings.location}</span>
              </div>
            </div>
          </div>

          <div>
            <h4 className="mb-4 text-emerald-400">Follow Me</h4>
            <div className="flex gap-4">
              {settings.instagram && (
                <a 
                  href={settings.instagram} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="bg-gradient-to-br from-gray-800 to-gray-900 p-3 rounded-xl hover:shadow-[0_0_20px_rgba(16,185,129,0.4)] transition-all border border-emerald-500/30 group"
                >
                  <Instagram className="w-5 h-5 text-gray-400 group-hover:text-emerald-400 transition-colors" />
                </a>
              )}
              {settings.youtube && (
                <a 
                  href={settings.youtube} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="bg-gradient-to-br from-gray-800 to-gray-900 p-3 rounded-xl hover:shadow-[0_0_20px_rgba(16,185,129,0.4)] transition-all border border-emerald-500/30 group"
                >
                  <Youtube className="w-5 h-5 text-gray-400 group-hover:text-emerald-400 transition-colors" />
                </a>
              )}
              {settings.linkedin && (
                <a 
                  href={settings.linkedin} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="bg-gradient-to-br from-gray-800 to-gray-900 p-3 rounded-xl hover:shadow-[0_0_20px_rgba(16,185,129,0.4)] transition-all border border-emerald-500/30 group"
                >
                  <Linkedin className="w-5 h-5 text-gray-400 group-hover:text-emerald-400 transition-colors" />
                </a>
              )}
            </div>
          </div>
        </div>

        <div className="border-t border-emerald-500/20 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} Sam Nyarwaya Video Editor. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}