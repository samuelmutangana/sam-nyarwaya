import { motion } from 'motion/react';
import { Camera, Film, Palette } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function Hero() {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden pt-20">
      {/* Dark background with green accents */}
      <div className="absolute inset-0 bg-gradient-to-br from-gray-900 via-black to-gray-900" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(16,185,129,0.1),transparent_50%)]" />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl md:text-7xl mb-6 bg-gradient-to-r from-emerald-400 via-teal-400 to-emerald-500 bg-clip-text text-transparent">
              Sam Nyarwaya
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              Professional Video Editor & Creative Visual Artist - Bringing your vision to life through exceptional camera work, expert video editing, and stunning graphic design.
            </p>
            
            <div className="flex flex-wrap gap-6">
              <motion.div 
                className="flex items-center gap-3 bg-gradient-to-br from-gray-800 to-gray-900 p-4 rounded-2xl shadow-[8px_8px_16px_rgba(0,0,0,0.4),-8px_-8px_16px_rgba(255,255,255,0.05)] border border-emerald-500/20"
                whileHover={{ scale: 1.05, boxShadow: "0 0 30px rgba(16,185,129,0.3)" }}
              >
                <div className="bg-gradient-to-br from-emerald-500 to-teal-600 p-3 rounded-xl shadow-[inset_2px_2px_5px_rgba(0,0,0,0.3)]">
                  <Camera className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-sm text-emerald-400">Camera</p>
                  <p className="text-white">Cinematography</p>
                </div>
              </motion.div>

              <motion.div 
                className="flex items-center gap-3 bg-gradient-to-br from-gray-800 to-gray-900 p-4 rounded-2xl shadow-[8px_8px_16px_rgba(0,0,0,0.4),-8px_-8px_16px_rgba(255,255,255,0.05)] border border-emerald-500/20"
                whileHover={{ scale: 1.05, boxShadow: "0 0 30px rgba(16,185,129,0.3)" }}
              >
                <div className="bg-gradient-to-br from-emerald-500 to-teal-600 p-3 rounded-xl shadow-[inset_2px_2px_5px_rgba(0,0,0,0.3)]">
                  <Film className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-sm text-emerald-400">Premiere Pro</p>
                  <p className="text-white">Video Editing</p>
                </div>
              </motion.div>

              <motion.div 
                className="flex items-center gap-3 bg-gradient-to-br from-gray-800 to-gray-900 p-4 rounded-2xl shadow-[8px_8px_16px_rgba(0,0,0,0.4),-8px_-8px_16px_rgba(255,255,255,0.05)] border border-emerald-500/20"
                whileHover={{ scale: 1.05, boxShadow: "0 0 30px rgba(16,185,129,0.3)" }}
              >
                <div className="bg-gradient-to-br from-emerald-500 to-teal-600 p-3 rounded-xl shadow-[inset_2px_2px_5px_rgba(0,0,0,0.3)]">
                  <Palette className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-sm text-emerald-400">Creative</p>
                  <p className="text-white">Graphic Design</p>
                </div>
              </motion.div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            {/* Glassmorphism frame */}
            <div className="relative rounded-3xl overflow-hidden shadow-[0_0_50px_rgba(16,185,129,0.3)] border border-emerald-500/30 bg-black/20 backdrop-blur-sm p-2">
              <ImageWithFallback 
                src="https://images.unsplash.com/photo-1583121182724-6f84970c0e77?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcmVhdGl2ZSUyMHBvcnRmb2xpb3xlbnwxfHx8fDE3NjU3NzAwMDZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Creative workspace"
                className="w-full h-auto rounded-2xl"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-emerald-900/20 to-transparent rounded-2xl" />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}