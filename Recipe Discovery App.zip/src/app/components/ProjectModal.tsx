import { X, ExternalLink } from 'lucide-react';
import { PortfolioItem } from '../types';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface ProjectModalProps {
  project: PortfolioItem | null;
  isOpen: boolean;
  onClose: () => void;
}

export function ProjectModal({ project, isOpen, onClose }: ProjectModalProps) {
  if (!isOpen || !project) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4 overflow-y-auto">
      <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-3xl shadow-[0_0_60px_rgba(16,185,129,0.4)] max-w-4xl w-full border border-emerald-500/30 my-8">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-emerald-500/30">
          <h2 className="text-2xl text-white">{project.title}</h2>
          <button 
            onClick={onClose}
            className="text-gray-400 hover:text-emerald-400 p-2 rounded-xl transition-colors hover:bg-emerald-500/10"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Main Image */}
          <div className="relative rounded-2xl overflow-hidden border border-emerald-500/30">
            <ImageWithFallback 
              src={project.imageUrl}
              alt={project.title}
              className="w-full h-auto"
            />
          </div>

          {/* Video if available */}
          {project.videoUrl && (
            <div className="relative rounded-2xl overflow-hidden border border-emerald-500/30 bg-black aspect-video">
              <iframe
                src={project.videoUrl}
                className="w-full h-full"
                allowFullScreen
                title={project.title}
              />
            </div>
          )}

          {/* Details */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="bg-gradient-to-br from-gray-700/50 to-gray-800/50 rounded-xl p-4 border border-emerald-500/20">
              <div className="text-sm text-gray-400 mb-1">Category</div>
              <div className="text-emerald-400 capitalize">{project.category}</div>
            </div>
            <div className="bg-gradient-to-br from-gray-700/50 to-gray-800/50 rounded-xl p-4 border border-emerald-500/20">
              <div className="text-sm text-gray-400 mb-1">Date</div>
              <div className="text-emerald-400">{project.date}</div>
            </div>
          </div>

          {/* Description */}
          <div className="bg-gradient-to-br from-gray-700/50 to-gray-800/50 rounded-xl p-6 border border-emerald-500/20">
            <h3 className="text-xl text-emerald-400 mb-3">Project Description</h3>
            <p className="text-gray-300 leading-relaxed whitespace-pre-line">
              {project.detailedDescription || project.description}
            </p>
          </div>

          {/* Additional Images */}
          {project.additionalImages && project.additionalImages.length > 0 && (
            <div>
              <h3 className="text-xl text-emerald-400 mb-4">More Images</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {project.additionalImages.map((img, index) => (
                  <div key={index} className="relative rounded-xl overflow-hidden border border-emerald-500/30">
                    <ImageWithFallback 
                      src={img}
                      alt={`${project.title} - ${index + 1}`}
                      className="w-full h-40 object-cover"
                    />
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
