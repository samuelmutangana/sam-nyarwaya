import { Menu, X } from 'lucide-react';
import { useState } from 'react';
import logo from 'figma:asset/c42e0062e2d8d4b154f265d43d0b379ff6c1995a.png';

interface HeaderProps {
  onLogoDoubleClick: () => void;
}

export function Header({ onLogoDoubleClick }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setMobileMenuOpen(false);
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50">
      {/* Glassmorphism background */}
      <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/50 to-black/60 backdrop-blur-xl border-b border-emerald-500/30 shadow-[0_4px_30px_rgba(16,185,129,0.2)]"></div>
      
      <nav className="container mx-auto px-4 py-2 relative">
        <div className="flex items-center justify-between">
          {/* Logo with enhanced design */}
          <div 
            className="cursor-pointer group relative"
            onDoubleClick={onLogoDoubleClick}
            title="Double click for admin access"
          >
            <div className="absolute -inset-2 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-2xl opacity-0 group-hover:opacity-20 blur-xl transition-opacity duration-500"></div>
            <div className="relative bg-gradient-to-br from-gray-800/80 to-gray-900/80 p-3 rounded-2xl border border-emerald-500/40 shadow-[8px_8px_16px_rgba(0,0,0,0.5),-4px_-4px_12px_rgba(16,185,129,0.1)] group-hover:shadow-[0_0_40px_rgba(16,185,129,0.4)] transition-all duration-300 backdrop-blur-sm">
              <img 
                src={logo} 
                alt="Sam Nyarwaya Video Editor" 
                className="h-14 w-auto transition-transform group-hover:scale-105"
              />
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-2">
            <button 
              onClick={() => scrollToSection('home')} 
              className="px-6 py-2.5 rounded-xl bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm text-emerald-400 hover:from-emerald-900/80 hover:to-gray-900/80 transition-all shadow-[5px_5px_10px_rgba(0,0,0,0.3),-5px_-5px_10px_rgba(255,255,255,0.05)] hover:shadow-[inset_5px_5px_10px_rgba(0,0,0,0.3),inset_-5px_-5px_10px_rgba(255,255,255,0.05)] border border-emerald-500/20"
            >
              Home
            </button>
            <button 
              onClick={() => scrollToSection('about')} 
              className="px-6 py-2.5 rounded-xl bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm text-emerald-400 hover:from-emerald-900/80 hover:to-gray-900/80 transition-all shadow-[5px_5px_10px_rgba(0,0,0,0.3),-5px_-5px_10px_rgba(255,255,255,0.05)] hover:shadow-[inset_5px_5px_10px_rgba(0,0,0,0.3),inset_-5px_-5px_10px_rgba(255,255,255,0.05)] border border-emerald-500/20"
            >
              About
            </button>
            <button 
              onClick={() => scrollToSection('portfolio')} 
              className="px-6 py-2.5 rounded-xl bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm text-emerald-400 hover:from-emerald-900/80 hover:to-gray-900/80 transition-all shadow-[5px_5px_10px_rgba(0,0,0,0.3),-5px_-5px_10px_rgba(255,255,255,0.05)] hover:shadow-[inset_5px_5px_10px_rgba(0,0,0,0.3),inset_-5px_-5px_10px_rgba(255,255,255,0.05)] border border-emerald-500/20"
            >
              Portfolio
            </button>
            <button 
              onClick={() => scrollToSection('contact')} 
              className="px-6 py-2.5 rounded-xl bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm text-emerald-400 hover:from-emerald-900/80 hover:to-gray-900/80 transition-all shadow-[5px_5px_10px_rgba(0,0,0,0.3),-5px_-5px_10px_rgba(255,255,255,0.05)] hover:shadow-[inset_5px_5px_10px_rgba(0,0,0,0.3),inset_-5px_-5px_10px_rgba(255,255,255,0.05)] border border-emerald-500/20"
            >
              Contact
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-emerald-400 bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm p-2 rounded-xl border border-emerald-500/20"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden mt-4 pb-4 flex flex-col gap-3">
            <button 
              onClick={() => scrollToSection('home')} 
              className="px-6 py-2.5 rounded-xl bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm text-emerald-400 transition-all shadow-[5px_5px_10px_rgba(0,0,0,0.3),-5px_-5px_10px_rgba(255,255,255,0.05)] text-left border border-emerald-500/20"
            >
              Home
            </button>
            <button 
              onClick={() => scrollToSection('about')} 
              className="px-6 py-2.5 rounded-xl bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm text-emerald-400 transition-all shadow-[5px_5px_10px_rgba(0,0,0,0.3),-5px_-5px_10px_rgba(255,255,255,0.05)] text-left border border-emerald-500/20"
            >
              About
            </button>
            <button 
              onClick={() => scrollToSection('portfolio')} 
              className="px-6 py-2.5 rounded-xl bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm text-emerald-400 transition-all shadow-[5px_5px_10px_rgba(0,0,0,0.3),-5px_-5px_10px_rgba(255,255,255,0.05)] text-left border border-emerald-500/20"
            >
              Portfolio
            </button>
            <button 
              onClick={() => scrollToSection('contact')} 
              className="px-6 py-2.5 rounded-xl bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm text-emerald-400 transition-all shadow-[5px_5px_10px_rgba(0,0,0,0.3),-5px_-5px_10px_rgba(255,255,255,0.05)] text-left border border-emerald-500/20"
            >
              Contact
            </button>
          </div>
        )}
      </nav>
    </header>
  );
}