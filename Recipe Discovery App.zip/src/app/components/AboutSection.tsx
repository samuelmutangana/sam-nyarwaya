import { motion } from 'motion/react';
import { Award, Briefcase, Users, TrendingUp } from 'lucide-react';
import { AboutMe } from '../types';

interface AboutSectionProps {
  about: AboutMe;
}

export function AboutSection({ about }: AboutSectionProps) {
  const stats = [
    { icon: Briefcase, label: 'Years Experience', value: about.experience },
    { icon: TrendingUp, label: 'Projects Completed', value: about.projectsCompleted },
    { icon: Users, label: 'Clients Satisfied', value: about.clientsSatisfied },
    { icon: Award, label: 'Awards Won', value: about.awardsWon },
  ];

  return (
    <section id="about" className="py-20 bg-gradient-to-br from-gray-900 via-black to-gray-900">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl mb-4 bg-gradient-to-r from-emerald-400 via-teal-400 to-emerald-500 bg-clip-text text-transparent">
            About Me
          </h2>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
            className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-3xl p-8 border border-emerald-500/20 shadow-[8px_8px_20px_rgba(0,0,0,0.5),-8px_-8px_20px_rgba(255,255,255,0.03)] mb-12"
          >
            <p className="text-gray-300 text-lg leading-relaxed whitespace-pre-line">
              {about.bio}
            </p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl p-6 border border-emerald-500/20 shadow-[8px_8px_16px_rgba(0,0,0,0.4),-8px_-8px_16px_rgba(255,255,255,0.05)] text-center hover:shadow-[0_0_30px_rgba(16,185,129,0.3)] transition-all"
              >
                <div className="bg-gradient-to-br from-emerald-500 to-teal-600 p-3 rounded-xl inline-flex mb-3 shadow-[inset_2px_2px_5px_rgba(0,0,0,0.3)]">
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
                <div className="text-3xl text-emerald-400 mb-2">{stat.value}</div>
                <div className="text-sm text-gray-400">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
