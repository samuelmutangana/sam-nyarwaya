import { useState } from 'react';
import { Plus, Trash2, Star } from 'lucide-react';
import { Testimonial } from '../../types';

interface AdminTestimonialsProps {
  testimonials: Testimonial[];
  onAdd: (testimonial: Omit<Testimonial, 'id'>) => void;
  onDelete: (id: string) => void;
}

export function AdminTestimonials({ testimonials, onAdd, onDelete }: AdminTestimonialsProps) {
  const [form, setForm] = useState({ name: '', role: '', company: '', message: '', rating: 5 });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.message) return alert('Fill required fields');
    onAdd(form);
    setForm({ name: '', role: '', company: '', message: '', rating: 5 });
  };

  return (
    <div className="grid md:grid-cols-2 gap-8">
      <div>
        <h3 className="text-xl mb-4 text-emerald-400"><Plus className="w-5 h-5 inline mr-2" />Add Testimonial</h3>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input type="text" value={form.name} onChange={(e) => setForm({...form, name: e.target.value})} className="w-full px-4 py-3 bg-gradient-to-br from-gray-700 to-gray-800 border border-emerald-500/30 rounded-xl text-white" placeholder="Client name *" />
          <input type="text" value={form.role} onChange={(e) => setForm({...form, role: e.target.value})} className="w-full px-4 py-3 bg-gradient-to-br from-gray-700 to-gray-800 border border-emerald-500/30 rounded-xl text-white" placeholder="Role" />
          <input type="text" value={form.company} onChange={(e) => setForm({...form, company: e.target.value})} className="w-full px-4 py-3 bg-gradient-to-br from-gray-700 to-gray-800 border border-emerald-500/30 rounded-xl text-white" placeholder="Company" />
          <textarea value={form.message} onChange={(e) => setForm({...form, message: e.target.value})} className="w-full px-4 py-3 bg-gradient-to-br from-gray-700 to-gray-800 border border-emerald-500/30 rounded-xl text-white resize-none" rows={4} placeholder="Testimonial message *" />
          <div>
            <label className="text-gray-300 mb-2 block flex items-center gap-2">Rating: {[...Array(form.rating)].map((_, i) => <Star key={i} className="w-4 h-4 text-emerald-400 fill-emerald-400" />)}</label>
            <input type="range" min="1" max="5" value={form.rating} onChange={(e) => setForm({...form, rating: Number(e.target.value)})} className="w-full" />
          </div>
          <button type="submit" className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 text-white py-3 rounded-xl">Add Testimonial</button>
        </form>
      </div>
      <div>
        <h3 className="text-xl mb-4 text-emerald-400">Testimonials ({testimonials.length})</h3>
        <div className="space-y-2 max-h-[500px] overflow-y-auto">
          {testimonials.map(t => (
            <div key={t.id} className="bg-gradient-to-br from-gray-700 to-gray-800 p-4 rounded-xl border border-emerald-500/20">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <div className="text-white">{t.name}</div>
                  <div className="text-sm text-gray-400">{t.role} at {t.company}</div>
                </div>
                <button onClick={() => onDelete(t.id)} className="text-red-400 hover:bg-red-500/20 p-2 rounded"><Trash2 className="w-4 h-4" /></button>
              </div>
              <p className="text-sm text-gray-300 mb-2">"{t.message}"</p>
              <div className="flex gap-1">{[...Array(5)].map((_, i) => <Star key={i} className={`w-3 h-3 ${i < t.rating ? 'text-emerald-400 fill-emerald-400' : 'text-gray-600'}`} />)}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
