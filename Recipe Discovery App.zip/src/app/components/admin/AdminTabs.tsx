import { FolderOpen, Settings, Award, Star, User, Mail, Download, BarChart3 } from 'lucide-react';

interface AdminTabsProps {
  activeTab: 'projects' | 'settings' | 'skills' | 'testimonials' | 'about' | 'messages' | 'export' | 'statistics';
  onTabChange: (tab: 'projects' | 'settings' | 'skills' | 'testimonials' | 'about' | 'messages' | 'export' | 'statistics') => void;
  messageCount: number;
}

export function AdminTabs({ activeTab, onTabChange, messageCount }: AdminTabsProps) {
  const tabs = [
    { id: 'statistics' as const, icon: BarChart3, label: 'Statistics' },
    { id: 'projects' as const, icon: FolderOpen, label: 'Projects' },
    { id: 'skills' as const, icon: Award, label: 'Skills' },
    { id: 'testimonials' as const, icon: Star, label: 'Testimonials' },
    { id: 'about' as const, icon: User, label: 'About Me' },
    { id: 'messages' as const, icon: Mail, label: 'Messages', badge: messageCount },
    { id: 'settings' as const, icon: Settings, label: 'Settings' },
    { id: 'export' as const, icon: Download, label: 'Export/Import' },
  ];

  return (
    <div className="flex gap-2 p-4 border-b border-emerald-500/20 bg-black/20 overflow-x-auto">
      {tabs.map(tab => (
        <button
          key={tab.id}
          onClick={() => onTabChange(tab.id)}
          className={`flex items-center gap-2 px-4 py-3 rounded-xl transition-all whitespace-nowrap relative ${
            activeTab === tab.id
              ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-[0_0_20px_rgba(16,185,129,0.3)]'
              : 'bg-gradient-to-br from-gray-700 to-gray-800 text-gray-400 hover:text-emerald-400 border border-emerald-500/20'
          }`}
        >
          <tab.icon className="w-5 h-5" />
          {tab.label}
          {tab.badge !== undefined && tab.badge > 0 && (
            <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
              {tab.badge}
            </span>
          )}
        </button>
      ))}
    </div>
  );
}