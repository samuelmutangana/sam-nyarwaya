import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, Users, Eye, Calendar, Globe, MousePointer } from 'lucide-react';
import { AnalyticsData } from '../../types';
import { getPageBreakdown, getTodayStats } from '../../utils/analytics';

interface AdminStatisticsProps {
  analytics: AnalyticsData;
}

export function AdminStatistics({ analytics }: AdminStatisticsProps) {
  const pageBreakdown = getPageBreakdown(analytics.pageViews);
  const todayStats = getTodayStats(analytics.pageViews);
  
  // Colors for charts
  const COLORS = ['#10b981', '#14b8a6', '#06b6d4', '#0ea5e9', '#3b82f6'];
  
  // Format date for display (shorter)
  const formattedDailyStats = analytics.dailyStats.map(stat => ({
    ...stat,
    displayDate: new Date(stat.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
  }));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-3xl text-emerald-400 mb-2">Website Analytics</h3>
          <p className="text-gray-400">Track your website visitors and engagement</p>
        </div>
        <Globe className="w-12 h-12 text-emerald-500/30" />
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-emerald-600 to-teal-600 rounded-2xl p-6 shadow-[0_0_30px_rgba(16,185,129,0.3)]">
          <div className="flex items-center justify-between mb-2">
            <Eye className="w-8 h-8 text-white/80" />
            <TrendingUp className="w-5 h-5 text-white/60" />
          </div>
          <div className="text-3xl text-white mb-1">{analytics.totalViews}</div>
          <div className="text-sm text-emerald-100">Total Views</div>
        </div>

        <div className="bg-gradient-to-br from-teal-600 to-cyan-600 rounded-2xl p-6 shadow-[0_0_30px_rgba(20,184,166,0.3)]">
          <div className="flex items-center justify-between mb-2">
            <Users className="w-8 h-8 text-white/80" />
          </div>
          <div className="text-3xl text-white mb-1">{analytics.uniqueVisitors}</div>
          <div className="text-sm text-teal-100">Unique Visitors</div>
        </div>

        <div className="bg-gradient-to-br from-cyan-600 to-blue-600 rounded-2xl p-6 shadow-[0_0_30px_rgba(6,182,212,0.3)]">
          <div className="flex items-center justify-between mb-2">
            <Calendar className="w-8 h-8 text-white/80" />
          </div>
          <div className="text-3xl text-white mb-1">{todayStats.views}</div>
          <div className="text-sm text-cyan-100">Views Today</div>
        </div>

        <div className="bg-gradient-to-br from-blue-600 to-indigo-600 rounded-2xl p-6 shadow-[0_0_30px_rgba(14,165,233,0.3)]">
          <div className="flex items-center justify-between mb-2">
            <MousePointer className="w-8 h-8 text-white/80" />
          </div>
          <div className="text-3xl text-white mb-1">{todayStats.visitors}</div>
          <div className="text-sm text-blue-100">Visitors Today</div>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Daily Views Chart */}
        <div className="bg-gradient-to-br from-gray-700/50 to-gray-800/50 rounded-2xl p-6 border border-emerald-500/20">
          <h4 className="text-xl text-emerald-400 mb-4">Daily Views (Last 30 Days)</h4>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={formattedDailyStats}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis 
                dataKey="displayDate" 
                stroke="#9ca3af" 
                tick={{ fontSize: 12 }}
                angle={-45}
                textAnchor="end"
                height={80}
              />
              <YAxis stroke="#9ca3af" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1f2937', 
                  border: '1px solid #10b981',
                  borderRadius: '8px',
                  color: '#fff'
                }}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="views" 
                stroke="#10b981" 
                strokeWidth={3}
                name="Page Views"
                dot={{ fill: '#10b981', r: 4 }}
              />
              <Line 
                type="monotone" 
                dataKey="uniqueVisitors" 
                stroke="#14b8a6" 
                strokeWidth={3}
                name="Unique Visitors"
                dot={{ fill: '#14b8a6', r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Page Views Bar Chart */}
        <div className="bg-gradient-to-br from-gray-700/50 to-gray-800/50 rounded-2xl p-6 border border-emerald-500/20">
          <h4 className="text-xl text-emerald-400 mb-4">Most Viewed Pages</h4>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={pageBreakdown.slice(0, 8)}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis 
                dataKey="page" 
                stroke="#9ca3af"
                tick={{ fontSize: 12 }}
                angle={-45}
                textAnchor="end"
                height={80}
              />
              <YAxis stroke="#9ca3af" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1f2937', 
                  border: '1px solid #10b981',
                  borderRadius: '8px',
                  color: '#fff'
                }}
              />
              <Bar dataKey="views" fill="#10b981" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Page Breakdown Pie Chart */}
      <div className="bg-gradient-to-br from-gray-700/50 to-gray-800/50 rounded-2xl p-6 border border-emerald-500/20">
        <h4 className="text-xl text-emerald-400 mb-4">Traffic Distribution</h4>
        <div className="flex flex-col md:flex-row items-center gap-8">
          <div className="w-full md:w-1/2">
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={pageBreakdown.slice(0, 5)}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ page, percent }) => `${page} (${(percent * 100).toFixed(0)}%)`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="views"
                >
                  {pageBreakdown.slice(0, 5).map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1f2937', 
                    border: '1px solid #10b981',
                    borderRadius: '8px',
                    color: '#fff'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          
          <div className="w-full md:w-1/2 space-y-3">
            <h5 className="text-lg text-emerald-400 mb-4">Page Views Breakdown</h5>
            {pageBreakdown.slice(0, 8).map((item, index) => (
              <div key={item.page} className="flex items-center justify-between p-3 bg-gray-800/50 rounded-xl border border-emerald-500/10">
                <div className="flex items-center gap-3">
                  <div 
                    className="w-4 h-4 rounded-full" 
                    style={{ backgroundColor: COLORS[index % COLORS.length] }}
                  />
                  <span className="text-gray-300">{item.page}</span>
                </div>
                <span className="text-emerald-400 font-semibold">{item.views}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Insights */}
      <div className="grid md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-gray-700/30 to-gray-800/30 rounded-xl p-6 border border-emerald-500/20">
          <h5 className="text-emerald-400 mb-2">Average Daily Views</h5>
          <p className="text-3xl text-white">
            {analytics.dailyStats.length > 0 
              ? Math.round(analytics.totalViews / analytics.dailyStats.filter(s => s.views > 0).length || 0)
              : 0}
          </p>
        </div>
        
        <div className="bg-gradient-to-br from-gray-700/30 to-gray-800/30 rounded-xl p-6 border border-emerald-500/20">
          <h5 className="text-emerald-400 mb-2">Most Popular Page</h5>
          <p className="text-xl text-white truncate">
            {pageBreakdown.length > 0 ? pageBreakdown[0].page : 'N/A'}
          </p>
        </div>
        
        <div className="bg-gradient-to-br from-gray-700/30 to-gray-800/30 rounded-xl p-6 border border-emerald-500/20">
          <h5 className="text-emerald-400 mb-2">Avg. Pages/Visitor</h5>
          <p className="text-3xl text-white">
            {analytics.uniqueVisitors > 0 
              ? (analytics.totalViews / analytics.uniqueVisitors).toFixed(1)
              : 0}
          </p>
        </div>
      </div>

      {/* Info Notice */}
      <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4">
        <p className="text-blue-300 text-sm">
          <strong>Note:</strong> Statistics are tracked locally in your browser. Data is stored for the last 1,000 page views. 
          For more advanced analytics, consider integrating Google Analytics.
        </p>
      </div>
    </div>
  );
}
