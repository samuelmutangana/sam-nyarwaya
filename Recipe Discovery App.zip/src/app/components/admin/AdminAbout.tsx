import { useState } from 'react';
import { User } from 'lucide-react';
import { AboutMe } from '../../types';

interface AdminAboutProps {
  about: AboutMe;
  onUpdate: (about: AboutMe) => void;
}

export function AdminAbout({ about, onUpdate }: AdminAboutProps) {
  const [form, setForm] = useState(about);

  const handleSave = () => {
    onUpdate(form);
    alert('About section updated!');
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="bg-gradient-to-br from-gray-700/50 to-gray-800/50 rounded-2xl p-6 border border-emerald-500/20">
        <h3 className="text-xl mb-4 flex items-center gap-2 text-emerald-400">
          <User className="w-5 h-5" />
          About Me
        </h3>
        <div className="space-y-4">
          <div>
            <label className="block text-gray-300 mb-2">Your Bio</label>
            <textarea 
              value={form.bio}
              onChange={(e) => setForm({...form, bio: e.target.value})}
              className="w-full px-4 py-3 bg-gradient-to-br from-gray-600 to-gray-700 border border-emerald-500/30 rounded-xl text-white resize-none"
              rows={6}
              placeholder="Tell your story..."
            />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-gray-700/50 to-gray-800/50 rounded-xl p-4 border border-emerald-500/20">
          <label className="block text-gray-300 mb-2 text-sm">Years Experience</label>
          <input 
            type="text"
            value={form.experience}
            onChange={(e) => setForm({...form, experience: e.target.value})}
            className="w-full px-3 py-2 bg-gradient-to-br from-gray-600 to-gray-700 border border-emerald-500/30 rounded-lg text-white text-center text-2xl"
            placeholder="5+"
          />
        </div>
        <div className="bg-gradient-to-br from-gray-700/50 to-gray-800/50 rounded-xl p-4 border border-emerald-500/20">
          <label className="block text-gray-300 mb-2 text-sm">Projects Done</label>
          <input 
            type="text"
            value={form.projectsCompleted}
            onChange={(e) => setForm({...form, projectsCompleted: e.target.value})}
            className="w-full px-3 py-2 bg-gradient-to-br from-gray-600 to-gray-700 border border-emerald-500/30 rounded-lg text-white text-center text-2xl"
            placeholder="100+"
          />
        </div>
        <div className="bg-gradient-to-br from-gray-700/50 to-gray-800/50 rounded-xl p-4 border border-emerald-500/20">
          <label className="block text-gray-300 mb-2 text-sm">Happy Clients</label>
          <input 
            type="text"
            value={form.clientsSatisfied}
            onChange={(e) => setForm({...form, clientsSatisfied: e.target.value})}
            className="w-full px-3 py-2 bg-gradient-to-br from-gray-600 to-gray-700 border border-emerald-500/30 rounded-lg text-white text-center text-2xl"
            placeholder="50+"
          />
        </div>
        <div className="bg-gradient-to-br from-gray-700/50 to-gray-800/50 rounded-xl p-4 border border-emerald-500/20">
          <label className="block text-gray-300 mb-2 text-sm">Awards Won</label>
          <input 
            type="text"
            value={form.awardsWon}
            onChange={(e) => setForm({...form, awardsWon: e.target.value})}
            className="w-full px-3 py-2 bg-gradient-to-br from-gray-600 to-gray-700 border border-emerald-500/30 rounded-lg text-white text-center text-2xl"
            placeholder="10+"
          />
        </div>
      </div>

      <button 
        onClick={handleSave}
        className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 text-white py-4 rounded-xl hover:shadow-[0_0_30px_rgba(16,185,129,0.5)] transition-all"
      >
        Save About Info
      </button>
    </div>
  );
}
