import { useState } from 'react';
import { Lock, Eye, EyeOff } from 'lucide-react';

interface AdminLoginProps {
  onLogin: (password: string) => boolean;
  onClose: () => void;
}

export function AdminLogin({ onLogin, onClose }: AdminLoginProps) {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onLogin(password)) {
      setPassword('');
    }
  };

  return (
    <div className="p-8 flex items-center justify-center min-h-[400px]">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl shadow-[8px_8px_16px_rgba(0,0,0,0.4),-8px_-8px_16px_rgba(255,255,255,0.05)] mb-4">
            <Lock className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-3xl bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent mb-2">
            Admin Access
          </h2>
          <p className="text-gray-400">Enter your password to continue</p>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <input 
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-6 py-4 pr-12 bg-gradient-to-br from-gray-700 to-gray-800 border border-emerald-500/30 rounded-2xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-white placeholder-gray-500 shadow-[inset_4px_4px_8px_rgba(0,0,0,0.3)]"
              placeholder="Enter password"
              autoFocus
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-emerald-400"
            >
              {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            </button>
          </div>

          <div className="flex gap-3">
            <button 
              type="submit"
              className="flex-1 bg-gradient-to-r from-emerald-500 to-teal-600 text-white py-4 rounded-2xl hover:shadow-[0_0_30px_rgba(16,185,129,0.5)] transition-all shadow-[8px_8px_16px_rgba(0,0,0,0.4),-8px_-8px_16px_rgba(255,255,255,0.05)]"
            >
              Login
            </button>
            <button 
              type="button"
              onClick={onClose}
              className="px-6 bg-gradient-to-br from-gray-700 to-gray-800 text-gray-300 py-4 rounded-2xl hover:bg-gray-700 transition-all border border-gray-600"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
