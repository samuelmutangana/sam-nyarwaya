import { useState } from 'react';
import { Key, Mail, Phone, MapPin, Instagram, Youtube, Linkedin, Eye, EyeOff } from 'lucide-react';
import { SiteSettings } from '../../types';

interface AdminSettingsProps {
  settings: SiteSettings;
  onUpdate: (settings: SiteSettings) => void;
}

export function AdminSettings({ settings, onUpdate }: AdminSettingsProps) {
  const [form, setForm] = useState(settings);
  const [showPassword, setShowPassword] = useState(false);

  const handleSave = () => {
    if (!form.adminPassword) {
      alert('Password cannot be empty');
      return;
    }
    onUpdate(form);
    alert('Settings saved!');
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      <div className="bg-gradient-to-br from-gray-700/50 to-gray-800/50 rounded-2xl p-6 border border-emerald-500/20">
        <h3 className="text-xl mb-4 flex items-center gap-2 text-emerald-400">
          <Key className="w-5 h-5" />
          Security
        </h3>
        <div className="relative">
          <input 
            type={showPassword ? "text" : "password"}
            value={form.adminPassword}
            onChange={(e) => setForm({ ...form, adminPassword: e.target.value })}
            className="w-full px-4 py-3 pr-12 bg-gradient-to-br from-gray-600 to-gray-700 border border-emerald-500/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-white"
            placeholder="Admin password"
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-emerald-400"
          >
            {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
          </button>
        </div>
      </div>

      <div className="bg-gradient-to-br from-gray-700/50 to-gray-800/50 rounded-2xl p-6 border border-emerald-500/20">
        <h3 className="text-xl mb-4 flex items-center gap-2 text-emerald-400">
          <Mail className="w-5 h-5" />
          Contact Info
        </h3>
        <div className="space-y-4">
          <input 
            type="email"
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            className="w-full px-4 py-3 bg-gradient-to-br from-gray-600 to-gray-700 border border-emerald-500/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-white"
            placeholder="Email"
          />
          <input 
            type="tel"
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            className="w-full px-4 py-3 bg-gradient-to-br from-gray-600 to-gray-700 border border-emerald-500/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-white"
            placeholder="Phone"
          />
          <input 
            type="text"
            value={form.location}
            onChange={(e) => setForm({ ...form, location: e.target.value })}
            className="w-full px-4 py-3 bg-gradient-to-br from-gray-600 to-gray-700 border border-emerald-500/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-white"
            placeholder="Location"
          />
        </div>
      </div>

      <div className="bg-gradient-to-br from-gray-700/50 to-gray-800/50 rounded-2xl p-6 border border-emerald-500/20">
        <h3 className="text-xl mb-4 flex items-center gap-2 text-emerald-400">
          <Instagram className="w-5 h-5" />
          Social Media
        </h3>
        <div className="space-y-4">
          <input 
            type="url"
            value={form.instagram}
            onChange={(e) => setForm({ ...form, instagram: e.target.value })}
            className="w-full px-4 py-3 bg-gradient-to-br from-gray-600 to-gray-700 border border-emerald-500/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-white"
            placeholder="Instagram URL"
          />
          <input 
            type="url"
            value={form.youtube}
            onChange={(e) => setForm({ ...form, youtube: e.target.value })}
            className="w-full px-4 py-3 bg-gradient-to-br from-gray-600 to-gray-700 border border-emerald-500/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-white"
            placeholder="YouTube URL"
          />
          <input 
            type="url"
            value={form.linkedin}
            onChange={(e) => setForm({ ...form, linkedin: e.target.value })}
            className="w-full px-4 py-3 bg-gradient-to-br from-gray-600 to-gray-700 border border-emerald-500/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-white"
            placeholder="LinkedIn URL"
          />
        </div>
      </div>

      <button 
        onClick={handleSave}
        className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 text-white py-4 rounded-xl hover:shadow-[0_0_30px_rgba(16,185,129,0.5)] transition-all"
      >
        Save Settings
      </button>
    </div>
  );
}
