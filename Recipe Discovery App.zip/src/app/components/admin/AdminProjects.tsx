import { useState } from 'react';
import { Plus, Trash2, Upload, X, Camera, Film, Palette } from 'lucide-react';
import { PortfolioItem } from '../../types';

interface AdminProjectsProps {
  items: PortfolioItem[];
  onAdd: (item: Omit<PortfolioItem, 'id'>) => void;
  onDelete: (id: string) => void;
}

export function AdminProjects({ items, onAdd, onDelete }: AdminProjectsProps) {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    imageUrl: '',
    category: 'camera' as 'camera' | 'editing' | 'design',
    detailedDescription: '',
    videoUrl: '',
  });

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setFormData({ ...formData, imageUrl: event.target?.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.description || !formData.imageUrl) {
      alert('Please fill in required fields');
      return;
    }

    onAdd({
      ...formData,
      date: new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
    });

    setFormData({
      title: '',
      description: '',
      imageUrl: '',
      category: 'camera',
      detailedDescription: '',
      videoUrl: '',
    });
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'camera': return <Camera className="w-4 h-4" />;
      case 'editing': return <Film className="w-4 h-4" />;
      case 'design': return <Palette className="w-4 h-4" />;
    }
  };

  return (
    <div className="grid md:grid-cols-2 gap-8">
      {/* Form */}
      <div>
        <h3 className="text-xl mb-4 flex items-center gap-2 text-emerald-400">
          <Plus className="w-5 h-5" />
          Add New Project
        </h3>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input 
            type="text"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            className="w-full px-4 py-3 bg-gradient-to-br from-gray-700 to-gray-800 border border-emerald-500/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-white placeholder-gray-500 shadow-[inset_4px_4px_8px_rgba(0,0,0,0.3)]"
            placeholder="Project Title *"
          />

          <textarea 
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            className="w-full px-4 py-3 bg-gradient-to-br from-gray-700 to-gray-800 border border-emerald-500/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-white placeholder-gray-500 resize-none shadow-[inset_4px_4px_8px_rgba(0,0,0,0.3)]"
            rows={3}
            placeholder="Short Description *"
          />

          <textarea 
            value={formData.detailedDescription}
            onChange={(e) => setFormData({ ...formData, detailedDescription: e.target.value })}
            className="w-full px-4 py-3 bg-gradient-to-br from-gray-700 to-gray-800 border border-emerald-500/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-white placeholder-gray-500 resize-none shadow-[inset_4px_4px_8px_rgba(0,0,0,0.3)]"
            rows={4}
            placeholder="Detailed Description (optional)"
          />

          <div>
            <label className="block text-sm mb-2 text-gray-300">Image (Double-click to upload)</label>
            <div className="relative">
              <input 
                type="text"
                value={formData.imageUrl}
                onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
                onDoubleClick={() => document.getElementById('projectImage')?.click()}
                className="w-full px-4 py-3 pr-12 bg-gradient-to-br from-gray-700 to-gray-800 border border-emerald-500/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-white placeholder-gray-500 shadow-[inset_4px_4px_8px_rgba(0,0,0,0.3)] cursor-pointer"
                placeholder="Image URL or double-click to upload *"
              />
              <button
                type="button"
                onClick={() => document.getElementById('projectImage')?.click()}
                className="absolute right-3 top-1/2 -translate-y-1/2 bg-emerald-500/20 hover:bg-emerald-500/30 p-2 rounded-lg transition-colors border border-emerald-500/30"
              >
                <Upload className="w-4 h-4 text-emerald-400" />
              </button>
              <input 
                id="projectImage"
                type="file"
                accept="image/*"
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>
            {formData.imageUrl && (
              <div className="mt-3 relative rounded-xl overflow-hidden border border-emerald-500/30">
                <img src={formData.imageUrl} alt="Preview" className="w-full h-40 object-cover" />
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, imageUrl: '' })}
                  className="absolute top-2 right-2 bg-red-500/80 hover:bg-red-500 p-2 rounded-lg transition-colors"
                >
                  <X className="w-4 h-4 text-white" />
                </button>
              </div>
            )}
          </div>

          <input 
            type="url"
            value={formData.videoUrl}
            onChange={(e) => setFormData({ ...formData, videoUrl: e.target.value })}
            className="w-full px-4 py-3 bg-gradient-to-br from-gray-700 to-gray-800 border border-emerald-500/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-white placeholder-gray-500 shadow-[inset_4px_4px_8px_rgba(0,0,0,0.3)]"
            placeholder="Video Embed URL (YouTube/Vimeo)"
          />

          <select 
            value={formData.category}
            onChange={(e) => setFormData({ ...formData, category: e.target.value as any })}
            className="w-full px-4 py-3 bg-gradient-to-br from-gray-700 to-gray-800 border border-emerald-500/30 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-white shadow-[inset_4px_4px_8px_rgba(0,0,0,0.3)]"
          >
            <option value="camera">Camera Work</option>
            <option value="editing">Video Editing</option>
            <option value="design">Graphic Design</option>
          </select>

          <button 
            type="submit"
            className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 text-white py-3 rounded-xl hover:shadow-[0_0_30px_rgba(16,185,129,0.5)] transition-all"
          >
            Add Project
          </button>
        </form>
      </div>

      {/* List */}
      <div>
        <h3 className="text-xl mb-4 text-emerald-400">Your Projects ({items.length})</h3>
        <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2">
          {items.length === 0 ? (
            <p className="text-gray-400 text-center py-8">No projects yet</p>
          ) : (
            items.map((item) => (
              <div 
                key={item.id}
                className="bg-gradient-to-br from-gray-700 to-gray-800 rounded-xl p-4 flex items-start gap-4 hover:shadow-[0_0_20px_rgba(16,185,129,0.2)] transition-all border border-emerald-500/20"
              >
                <img 
                  src={item.imageUrl}
                  alt={item.title}
                  className="w-20 h-20 object-cover rounded-lg border border-emerald-500/30"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="truncate text-white">{item.title}</h4>
                    <span className="flex items-center gap-1 px-2 py-1 rounded text-xs bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      {getCategoryIcon(item.category)}
                      {item.category}
                    </span>
                  </div>
                  <p className="text-sm text-gray-400 line-clamp-2">{item.description}</p>
                  <p className="text-xs text-emerald-400 mt-1">{item.date}</p>
                </div>
                <button 
                  onClick={() => onDelete(item.id)}
                  className="text-red-400 hover:bg-red-500/20 p-2 rounded-lg transition-colors flex-shrink-0 border border-red-500/30"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
