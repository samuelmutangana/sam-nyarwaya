import { Trash2, Mail, MailOpen } from 'lucide-react';
import { ContactMessage } from '../../types';

interface AdminMessagesProps {
  messages: ContactMessage[];
  onDelete: (id: string) => void;
  onMarkRead: (id: string) => void;
}

export function AdminMessages({ messages, onDelete, onMarkRead }: AdminMessagesProps) {
  return (
    <div className="max-w-4xl mx-auto">
      <h3 className="text-2xl mb-6 text-emerald-400">Contact Messages ({messages.length})</h3>
      {messages.length === 0 ? (
        <p className="text-gray-400 text-center py-12">No messages yet</p>
      ) : (
        <div className="space-y-4">
          {messages.map(msg => (
            <div key={msg.id} className={`bg-gradient-to-br from-gray-700 to-gray-800 rounded-xl p-6 border ${msg.status === 'new' ? 'border-emerald-500/40' : 'border-emerald-500/20'}`}>
              <div className="flex justify-between items-start mb-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-white">{msg.name}</span>
                    {msg.status === 'new' && <span className="px-2 py-1 bg-emerald-500/20 text-emerald-400 text-xs rounded border border-emerald-500/30">New</span>}
                  </div>
                  <div className="text-sm text-gray-400">{msg.email} • {msg.projectType}</div>
                  <div className="text-xs text-gray-500">{msg.date}</div>
                </div>
                <div className="flex gap-2">
                  {msg.status === 'new' && (
                    <button onClick={() => onMarkRead(msg.id)} className="text-emerald-400 hover:bg-emerald-500/20 p-2 rounded" title="Mark as read">
                      <MailOpen className="w-5 h-5" />
                    </button>
                  )}
                  <button onClick={() => onDelete(msg.id)} className="text-red-400 hover:bg-red-500/20 p-2 rounded">
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
              <p className="text-gray-300">{msg.message}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
