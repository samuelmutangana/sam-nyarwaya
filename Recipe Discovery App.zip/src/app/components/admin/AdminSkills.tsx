import { useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { Skill } from '../../types';

interface AdminSkillsProps {
  skills: Skill[];
  onAdd: (skill: Omit<Skill, 'id'>) => void;
  onDelete: (id: string) => void;
}

export function AdminSkills({ skills, onAdd, onDelete }: AdminSkillsProps) {
  const [form, setForm] = useState({ name: '', category: '', level: 80 });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.category) return alert('Fill all fields');
    onAdd(form);
    setForm({ name: '', category: '', level: 80 });
  };

  return (
    <div className="grid md:grid-cols-2 gap-8">
      <div>
        <h3 className="text-xl mb-4 text-emerald-400"><Plus className="w-5 h-5 inline mr-2" />Add Skill</h3>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input type="text" value={form.name} onChange={(e) => setForm({...form, name: e.target.value})} className="w-full px-4 py-3 bg-gradient-to-br from-gray-700 to-gray-800 border border-emerald-500/30 rounded-xl text-white" placeholder="Skill name" />
          <input type="text" value={form.category} onChange={(e) => setForm({...form, category: e.target.value})} className="w-full px-4 py-3 bg-gradient-to-br from-gray-700 to-gray-800 border border-emerald-500/30 rounded-xl text-white" placeholder="Category (e.g., Software)" />
          <div>
            <label className="text-gray-300 mb-2 block">Level: {form.level}%</label>
            <input type="range" min="0" max="100" value={form.level} onChange={(e) => setForm({...form, level: Number(e.target.value)})} className="w-full" />
          </div>
          <button type="submit" className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 text-white py-3 rounded-xl">Add Skill</button>
        </form>
      </div>
      <div>
        <h3 className="text-xl mb-4 text-emerald-400">Skills ({skills.length})</h3>
        <div className="space-y-2 max-h-[500px] overflow-y-auto">
          {skills.map(s => (
            <div key={s.id} className="bg-gradient-to-br from-gray-700 to-gray-800 p-4 rounded-xl flex justify-between items-center border border-emerald-500/20">
              <div className="flex-1">
                <div className="text-white">{s.name}</div>
                <div className="text-sm text-gray-400">{s.category} - {s.level}%</div>
              </div>
              <button onClick={() => onDelete(s.id)} className="text-red-400 hover:bg-red-500/20 p-2 rounded"><Trash2 className="w-5 h-5" /></button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
