import { motion } from 'motion/react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { ExternalLink } from 'lucide-react';
import { PortfolioItem } from '../types';
import { useState } from 'react';

interface PortfolioSectionProps {
  id: string;
  title: string;
  description: string;
  items: PortfolioItem[];
  isDark?: boolean;
  onProjectClick: (project: PortfolioItem) => void;
}

export function PortfolioSection({ id, title, description, items, isDark = false, onProjectClick }: PortfolioSectionProps) {
  const [filter, setFilter] = useState<'all' | 'camera' | 'editing' | 'design'>('all');

  const filteredItems = filter === 'all' ? items : items.filter(item => item.category === filter);

  return (
    <section id={id} className={`py-20 ${isDark ? 'bg-gradient-to-br from-gray-900 via-black to-gray-900' : 'bg-gradient-to-br from-gray-800 via-gray-900 to-black'}`}>
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-8"
        >
          <h2 className="text-4xl md:text-5xl mb-4 bg-gradient-to-r from-emerald-400 via-teal-400 to-emerald-500 bg-clip-text text-transparent">
            {title}
          </h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            {description}
          </p>
        </motion.div>

        {/* Filter Buttons */}
        {id === 'portfolio' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
            className="flex flex-wrap justify-center gap-4 mb-12"
          >
            <button
              onClick={() => setFilter('all')}
              className={`px-6 py-3 rounded-xl transition-all ${
                filter === 'all'
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-[0_0_20px_rgba(16,185,129,0.4)]'
                  : 'bg-gradient-to-br from-gray-800 to-gray-900 text-gray-400 hover:text-emerald-400 border border-emerald-500/20'
              }`}
            >
              All Projects
            </button>
            <button
              onClick={() => setFilter('camera')}
              className={`px-6 py-3 rounded-xl transition-all ${
                filter === 'camera'
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-[0_0_20px_rgba(16,185,129,0.4)]'
                  : 'bg-gradient-to-br from-gray-800 to-gray-900 text-gray-400 hover:text-emerald-400 border border-emerald-500/20'
              }`}
            >
              Camera Work
            </button>
            <button
              onClick={() => setFilter('editing')}
              className={`px-6 py-3 rounded-xl transition-all ${
                filter === 'editing'
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-[0_0_20px_rgba(16,185,129,0.4)]'
                  : 'bg-gradient-to-br from-gray-800 to-gray-900 text-gray-400 hover:text-emerald-400 border border-emerald-500/20'
              }`}
            >
              Video Editing
            </button>
            <button
              onClick={() => setFilter('design')}
              className={`px-6 py-3 rounded-xl transition-all ${
                filter === 'design'
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-[0_0_20px_rgba(16,185,129,0.4)]'
                  : 'bg-gradient-to-br from-gray-800 to-gray-900 text-gray-400 hover:text-emerald-400 border border-emerald-500/20'
              }`}
            >
              Graphic Design
            </button>
          </motion.div>
        )}

        {filteredItems.length === 0 ? (
          <div className="text-center py-12">
            <div className="bg-gradient-to-br from-gray-800 to-gray-900 p-8 rounded-3xl border border-emerald-500/20 shadow-[8px_8px_16px_rgba(0,0,0,0.4),-8px_-8px_16px_rgba(255,255,255,0.05)] max-w-md mx-auto">
              <p className="text-gray-400 text-lg">No projects yet. Add some from the admin panel!</p>
            </div>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredItems.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -8 }}
                onClick={() => onProjectClick(item)}
                className="group bg-gradient-to-br from-gray-800 to-gray-900 rounded-3xl overflow-hidden shadow-[8px_8px_20px_rgba(0,0,0,0.5),-8px_-8px_20px_rgba(255,255,255,0.03)] hover:shadow-[0_0_40px_rgba(16,185,129,0.3)] transition-all cursor-pointer border border-emerald-500/10"
              >
                <div className="relative h-64 overflow-hidden">
                  <ImageWithFallback 
                    src={item.imageUrl}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent opacity-60 group-hover:opacity-80 transition-opacity duration-300" />
                  <div className="absolute inset-0 flex items-end justify-end p-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="bg-emerald-500/20 backdrop-blur-md p-3 rounded-xl border border-emerald-500/30">
                      <ExternalLink className="w-6 h-6 text-emerald-400" />
                    </div>
                  </div>
                </div>
                <div className="p-6 bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm">
                  <p className="text-sm text-emerald-400 mb-2">{item.date}</p>
                  <h3 className="text-xl mb-2 text-white">{item.title}</h3>
                  <p className="text-gray-400 line-clamp-2">{item.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}