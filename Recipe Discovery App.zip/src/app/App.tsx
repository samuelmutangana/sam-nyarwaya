import { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { AboutSection } from './components/AboutSection';
import { SkillsSection } from './components/SkillsSection';
import { PortfolioSection } from './components/PortfolioSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { ProjectModal } from './components/ProjectModal';
import { EnhancedAdminPanel } from './components/EnhancedAdminPanel';
import { PortfolioItem, SiteSettings, Skill, Testimonial, AboutMe, ContactMessage, AnalyticsData } from './types';
import { trackPageView, getAnalyticsData } from './utils/analytics';

// Initial data
const initialData: PortfolioItem[] = [
  {
    id: '1',
    title: 'Cinematic Short Film',
    description: 'Professional cinematography for an independent short film with dynamic camera movements.',
    imageUrl: 'https://images.unsplash.com/photo-1760782926423-50ee782ef076?w=1080',
    category: 'camera',
    date: 'Dec 2025',
  },
  {
    id: '2',
    title: 'Commercial Video Edit',
    description: 'Fast-paced commercial editing in Premiere Pro with color grading.',
    imageUrl: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=1080',
    category: 'editing',
    date: 'Nov 2025',
  },
  {
    id: '3',
    title: 'Brand Identity Design',
    description: 'Complete brand identity package including logo and visual guidelines.',
    imageUrl: 'https://images.unsplash.com/photo-1609921212029-bb5a28e60960?w=1080',
    category: 'design',
    date: 'Oct 2025',
  },
];

const defaultSettings: SiteSettings = {
  adminPassword: 'admin123',
  email: 'samnyarwaya@editor.com',
  phone: '+1 (555) 123-4567',
  location: 'Available Worldwide',
  instagram: 'https://instagram.com/samnyarwaya',
  youtube: 'https://youtube.com/@samnyarwaya',
  linkedin: 'https://linkedin.com/in/samnyarwaya',
};

const defaultAbout: AboutMe = {
  bio: "I'm a passionate video editor and creative visual artist with years of experience in camera work, video editing, and graphic design. I specialize in bringing stories to life through compelling visuals and professional editing.\n\nMy journey in the creative industry has allowed me to work with diverse clients, from independent filmmakers to major brands, delivering exceptional results that exceed expectations.",
  experience: '5+',
  projectsCompleted: '100+',
  clientsSatisfied: '50+',
  awardsWon: '10+',
};

const defaultSkills: Skill[] = [
  { id: '1', name: 'Adobe Premiere Pro', category: 'Video Editing', level: 95 },
  { id: '2', name: 'DaVinci Resolve', category: 'Video Editing', level: 85 },
  { id: '3', name: 'Camera Operation', category: 'Cinematography', level: 90 },
  { id: '4', name: 'Adobe Photoshop', category: 'Design', level: 88 },
  { id: '5', name: 'Color Grading', category: 'Video Editing', level: 92 },
];

function App() {
  const [portfolioItems, setPortfolioItems] = useState<PortfolioItem[]>([]);
  const [skills, setSkills] = useState<Skill[]>([]);
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [about, setAbout] = useState<AboutMe>(defaultAbout);
  const [settings, setSettings] = useState<SiteSettings>(defaultSettings);
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [adminOpen, setAdminOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState<PortfolioItem | null>(null);
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData | null>(null);

  // Load from localStorage
  useEffect(() => {
    const loadData = (key: string, defaultValue: any) => {
      const saved = localStorage.getItem(key);
      return saved ? JSON.parse(saved) : defaultValue;
    };

    setPortfolioItems(loadData('portfolioItems', initialData));
    setSkills(loadData('skills', defaultSkills));
    setTestimonials(loadData('testimonials', []));
    setAbout(loadData('about', defaultAbout));
    setSettings(loadData('siteSettings', defaultSettings));
    setMessages(loadData('contactMessages', []));
  }, []);

  // Save to localStorage
  useEffect(() => {
    if (portfolioItems.length > 0) localStorage.setItem('portfolioItems', JSON.stringify(portfolioItems));
  }, [portfolioItems]);
  
  useEffect(() => {
    if (skills.length > 0) localStorage.setItem('skills', JSON.stringify(skills));
  }, [skills]);
  
  useEffect(() => {
    localStorage.setItem('testimonials', JSON.stringify(testimonials));
  }, [testimonials]);
  
  useEffect(() => {
    localStorage.setItem('about', JSON.stringify(about));
  }, [about]);
  
  useEffect(() => {
    localStorage.setItem('siteSettings', JSON.stringify(settings));
  }, [settings]);
  
  useEffect(() => {
    localStorage.setItem('contactMessages', JSON.stringify(messages));
  }, [messages]);

  // Handlers
  const handleAddItem = (item: Omit<PortfolioItem, 'id'>) => {
    setPortfolioItems([...portfolioItems, { ...item, id: Date.now().toString() }]);
  };

  const handleDeleteItem = (id: string) => {
    setPortfolioItems(portfolioItems.filter(item => item.id !== id));
  };

  const handleAddSkill = (skill: Omit<Skill, 'id'>) => {
    setSkills([...skills, { ...skill, id: Date.now().toString() }]);
  };

  const handleDeleteSkill = (id: string) => {
    setSkills(skills.filter(s => s.id !== id));
  };

  const handleAddTestimonial = (testimonial: Omit<Testimonial, 'id'>) => {
    setTestimonials([...testimonials, { ...testimonial, id: Date.now().toString() }]);
  };

  const handleDeleteTestimonial = (id: string) => {
    setTestimonials(testimonials.filter(t => t.id !== id));
  };

  const handleSubmitMessage = (message: Omit<ContactMessage, 'id' | 'date' | 'status'>) => {
    const newMessage: ContactMessage = {
      ...message,
      id: Date.now().toString(),
      date: new Date().toLocaleDateString(),
      status: 'new',
    };
    setMessages([newMessage, ...messages]);
  };

  const handleDeleteMessage = (id: string) => {
    setMessages(messages.filter(m => m.id !== id));
  };

  const handleMarkMessageRead = (id: string) => {
    setMessages(messages.map(m => m.id === id ? { ...m, status: 'read' as const } : m));
  };

  // Analytics
  useEffect(() => {
    // Track page view on initial load
    trackPageView('Home');
    
    // Load analytics data
    setAnalyticsData(getAnalyticsData());
  }, []);

  // Update analytics when admin panel opens
  const handleOpenAdmin = () => {
    setAdminOpen(true);
    setAnalyticsData(getAnalyticsData());
  };

  return (
    <div className="min-h-screen bg-black">
      <Header onLogoDoubleClick={handleOpenAdmin} />
      
      <Hero />
      
      <AboutSection about={about} />
      
      <SkillsSection skills={skills} />
      
      <PortfolioSection 
        id="portfolio"
        title="My Portfolio"
        description="Explore my recent work across camera, video editing, and graphic design"
        items={portfolioItems}
        isDark={true}
        onProjectClick={setSelectedProject}
      />
      
      <TestimonialsSection testimonials={testimonials} />
      
      <ContactSection settings={settings} onSubmitMessage={handleSubmitMessage} />
      
      <Footer settings={settings} />

      <ProjectModal 
        project={selectedProject}
        isOpen={!!selectedProject}
        onClose={() => setSelectedProject(null)}
      />

      <EnhancedAdminPanel 
        isOpen={adminOpen}
        onClose={() => setAdminOpen(false)}
        portfolioItems={portfolioItems}
        onAddItem={handleAddItem}
        onDeleteItem={handleDeleteItem}
        settings={settings}
        onUpdateSettings={setSettings}
        skills={skills}
        onAddSkill={handleAddSkill}
        onDeleteSkill={handleDeleteSkill}
        testimonials={testimonials}
        onAddTestimonial={handleAddTestimonial}
        onDeleteTestimonial={handleDeleteTestimonial}
        about={about}
        onUpdateAbout={setAbout}
        messages={messages}
        onDeleteMessage={handleDeleteMessage}
        onMarkMessageRead={handleMarkMessageRead}
        analytics={analyticsData || { totalViews: 0, uniqueVisitors: 0, pageViews: [], dailyStats: [] }}
      />
    </div>
  );
}

export default App;