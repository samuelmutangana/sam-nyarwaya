import { PageView, VisitorStats, AnalyticsData } from '../types';

// Generate or get session ID
export function getSessionId(): string {
  let sessionId = sessionStorage.getItem('sessionId');
  if (!sessionId) {
    sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    sessionStorage.setItem('sessionId', sessionId);
  }
  return sessionId;
}

// Track page view
export function trackPageView(page: string): void {
  const sessionId = getSessionId();
  const pageView: PageView = {
    id: `view_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    page,
    timestamp: Date.now(),
    date: new Date().toLocaleDateString(),
    sessionId,
  };

  // Get existing page views
  const existingViews = localStorage.getItem('pageViews');
  const pageViews: PageView[] = existingViews ? JSON.parse(existingViews) : [];
  
  // Add new view
  pageViews.push(pageView);
  
  // Keep only last 1000 views to avoid storage issues
  if (pageViews.length > 1000) {
    pageViews.splice(0, pageViews.length - 1000);
  }
  
  localStorage.setItem('pageViews', JSON.stringify(pageViews));
}

// Get analytics data
export function getAnalyticsData(): AnalyticsData {
  const pageViewsStr = localStorage.getItem('pageViews');
  const pageViews: PageView[] = pageViewsStr ? JSON.parse(pageViewsStr) : [];
  
  // Calculate unique visitors (unique session IDs)
  const uniqueSessions = new Set(pageViews.map(pv => pv.sessionId));
  const uniqueVisitors = uniqueSessions.size;
  
  // Calculate daily stats (last 30 days)
  const dailyStatsMap = new Map<string, { views: number; sessions: Set<string> }>();
  const last30Days = getLast30Days();
  
  // Initialize all days with 0
  last30Days.forEach(date => {
    dailyStatsMap.set(date, { views: 0, sessions: new Set() });
  });
  
  // Count views per day
  pageViews.forEach(pv => {
    if (dailyStatsMap.has(pv.date)) {
      const stats = dailyStatsMap.get(pv.date)!;
      stats.views++;
      stats.sessions.add(pv.sessionId);
    }
  });
  
  // Convert to array
  const dailyStats: VisitorStats[] = Array.from(dailyStatsMap.entries()).map(([date, stats]) => ({
    date,
    views: stats.views,
    uniqueVisitors: stats.sessions.size,
  }));
  
  return {
    totalViews: pageViews.length,
    uniqueVisitors,
    pageViews,
    dailyStats,
  };
}

// Get last 30 days
function getLast30Days(): string[] {
  const days: string[] = [];
  for (let i = 29; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    days.push(date.toLocaleDateString());
  }
  return days;
}

// Get page view breakdown
export function getPageBreakdown(pageViews: PageView[]): { page: string; views: number }[] {
  const pageMap = new Map<string, number>();
  
  pageViews.forEach(pv => {
    pageMap.set(pv.page, (pageMap.get(pv.page) || 0) + 1);
  });
  
  return Array.from(pageMap.entries())
    .map(([page, views]) => ({ page, views }))
    .sort((a, b) => b.views - a.views);
}

// Get today's stats
export function getTodayStats(pageViews: PageView[]): { views: number; visitors: number } {
  const today = new Date().toLocaleDateString();
  const todayViews = pageViews.filter(pv => pv.date === today);
  const todayVisitors = new Set(todayViews.map(pv => pv.sessionId)).size;
  
  return {
    views: todayViews.length,
    visitors: todayVisitors,
  };
}
