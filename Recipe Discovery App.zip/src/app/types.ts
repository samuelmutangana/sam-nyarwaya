export interface PortfolioItem {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  category: 'camera' | 'editing' | 'design';
  date: string;
  detailedDescription?: string;
  videoUrl?: string;
  additionalImages?: string[];
}

export interface SiteSettings {
  adminPassword: string;
  email: string;
  phone: string;
  location: string;
  instagram: string;
  youtube: string;
  linkedin: string;
}

export interface Skill {
  id: string;
  name: string;
  category: string;
  level: number;
  icon?: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  company: string;
  message: string;
  rating: number;
  image?: string;
}

export interface AboutMe {
  bio: string;
  experience: string;
  projectsCompleted: string;
  clientsSatisfied: string;
  awardsWon: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  projectType: string;
  message: string;
  date: string;
  status: 'new' | 'read' | 'replied';
}

export interface VisitorStats {
  date: string;
  views: number;
  uniqueVisitors: number;
}

export interface PageView {
  id: string;
  page: string;
  timestamp: number;
  date: string;
  sessionId: string;
}

export interface AnalyticsData {
  totalViews: number;
  uniqueVisitors: number;
  pageViews: PageView[];
  dailyStats: VisitorStats[];
}